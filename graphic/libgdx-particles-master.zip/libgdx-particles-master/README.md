libgdx-particles
================

my particle effect presets


[![Bitdeli Badge](https://d2weczhvl823v0.cloudfront.net/vyorkin/libgdx-particles/trend.png)](https://bitdeli.com/free "Bitdeli Badge")

